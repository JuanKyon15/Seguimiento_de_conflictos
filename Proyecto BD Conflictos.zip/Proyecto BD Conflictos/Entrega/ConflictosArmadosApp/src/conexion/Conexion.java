/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    Connection conectar = null;

    public Connection conectar() {

        try {

            String usuario = "sa";
            String password = "123456";
            String bd = "ConflictosArmados";

            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=" + bd
                    + ";encrypt=true;"
                    + ";trustServerCertificate=true;";

            conectar = DriverManager.getConnection(url, usuario, password);

            System.out.println("Conexión exitosa");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());

        }

        return conectar;
    }
}
