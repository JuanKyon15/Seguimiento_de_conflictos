SELECT        c.nombre_conflicto, om.nombre_organizacion, a.nombre_ayuda, com.personas_desplegadas
FROM          dbo.CONFLICTOS AS c INNER JOIN
              dbo.CONFLICTOS_ORGANIZACIONES_MEDIADORAS AS com ON c.codigo_conflicto = com.codigo_conflicto INNER JOIN
              dbo.ORGANIZACIONES_MEDIADORAS AS om ON om.codigo_organizacion = com.codigo_organizacion INNER JOIN
              dbo.AYUDAS AS a ON a.id_ayuda = com.id_ayuda