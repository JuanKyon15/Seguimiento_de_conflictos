SELECT c.codigo_conflicto, c.nombre_conflicto, g.nombre_grupo_armado, lp.nombre_lider_politico
FROM   dbo.CONFLICTOS AS c INNER JOIN
       dbo.CONFLICTOS_GRUPOS_ARMADOS AS cga ON c.codigo_conflicto = cga.codigo_conflicto INNER JOIN
       dbo.GRUPOS_ARMADOS AS g ON g.codigo_grupo_armado = cga.codigo_grupo_armado INNER JOIN
       dbo.LIDERES_POLITICOS AS lp ON lp.codigo_grupo_armado = g.codigo_grupo_armado