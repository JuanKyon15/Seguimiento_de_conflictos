SELECT        t.nombre_traficante, a.nombre_arma, ta.cantidad
FROM          dbo.TRAFICANTES AS t INNER JOIN
              dbo.TRAFICANTES_ARMAS AS ta ON t.codigo_traficante = ta.codigo_traficante INNER JOIN
              dbo.ARMAS AS a ON a.codigo_arma = ta.codigo_arma