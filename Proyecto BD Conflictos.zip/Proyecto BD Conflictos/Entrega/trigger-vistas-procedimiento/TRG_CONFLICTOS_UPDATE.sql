CREATE TRIGGER TRG_CONFLICTOS_UPDATE
ON CONFLICTOS
AFTER UPDATE
AS
BEGIN

    INSERT INTO BITACORA_CONFLICTOS
    (
        codigo_conflicto,
        nombre_conflicto,
        fecha_registro,
        observacion
    )

    SELECT
        codigo_conflicto,
        nombre_conflicto,
        GETDATE(),
        'Se actualiz� el conflicto'

    FROM inserted;

END;