-- ================================================================
-- SCRIPT DE INSERCIÓN - 50 REGISTROS POR TABLA
-- Base de datos: CONFLICTOS
-- Motor: SQL Server (IDENTITY columns)
-- Todas las FK y PK validadas manualmente
-- ================================================================

-- ================================================================
-- BLOQUE 1: NIVELES_DESTRUCTIVOS (sin FK) — 50 registros
-- IDs generados: 1-50
-- ================================================================
INSERT INTO NIVELES_DESTRUCTIVOS (descripcion) VALUES
('Nivel 1 - Armas blancas y artesanales'),
('Nivel 2 - Pistolas y revólveres de pequeño calibre'),
('Nivel 3 - Fusiles de asalto automáticos'),
('Nivel 4 - Ametralladoras pesadas'),
('Nivel 5 - Granadas de fragmentación'),
('Nivel 6 - Morteros de 60mm'),
('Nivel 7 - Morteros de 120mm'),
('Nivel 8 - RPG y lanzacohetes portátiles'),
('Nivel 9 - Artillería de campaña'),
('Nivel 10 - Obuses autopropulsados'),
('Nivel 11 - Misiles tierra-aire MANPADS'),
('Nivel 12 - Misiles antitanque guiados'),
('Nivel 13 - Tanques de batalla principales'),
('Nivel 14 - Vehículos blindados de combate'),
('Nivel 15 - Helicópteros de ataque'),
('Nivel 16 - Aviones de combate subsónicos'),
('Nivel 17 - Aviones de combate supersónicos'),
('Nivel 18 - Drones de vigilancia armados'),
('Nivel 19 - Misiles balísticos de corto alcance'),
('Nivel 20 - Misiles balísticos de medio alcance'),
('Nivel 21 - Misiles de crucero convencionales'),
('Nivel 22 - Barcos patrulleros armados'),
('Nivel 23 - Fragatas y destructores navales'),
('Nivel 24 - Submarinos convencionales'),
('Nivel 25 - VBIED - vehículos bomba'),
('Nivel 26 - IED improvisados de alto poder'),
('Nivel 27 - Bombas de racimo'),
('Nivel 28 - Munición incendiaria'),
('Nivel 29 - Fósforo blanco'),
('Nivel 30 - Armas termobáricas'),
('Nivel 31 - Minas antipersona'),
('Nivel 32 - Minas antitanque'),
('Nivel 33 - Sistemas de artillería múltiple'),
('Nivel 34 - Misiles superficie-superficie de largo alcance'),
('Nivel 35 - Sistemas antiaéreos de largo alcance'),
('Nivel 36 - Bombas guiadas por láser'),
('Nivel 37 - Bombas de penetración de búnkeres'),
('Nivel 38 - Armas de radiofrecuencia de alta potencia'),
('Nivel 39 - Armas electromagnéticas no letales'),
('Nivel 40 - Agentes lacrimógenos militares'),
('Nivel 41 - Agentes incapacitantes'),
('Nivel 42 - Agentes químicos de primer nivel (prohibidos)'),
('Nivel 43 - Armas biológicas (prohibidas)'),
('Nivel 44 - Dispositivos nucleares tácticos'),
('Nivel 45 - Bombas nucleares estratégicas'),
('Nivel 46 - Misiles hipersónicos'),
('Nivel 47 - Sistemas de guerra cibernética ofensiva'),
('Nivel 48 - Explosivos plásticos C4 y similares'),
('Nivel 49 - Bombas de vacío'),
('Nivel 50 - Drones enjambre con carga explosiva');

-- ================================================================
-- BLOQUE 2: TIPO_ORGANIZACION (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO TIPO_ORGANIZACION (nombre_tipo_organizacion) VALUES
('Organización No Gubernamental Internacional'),
('Agencia especializada de la ONU'),
('Organización regional intergubernamental africana'),
('Organización regional intergubernamental europea'),
('Organización regional intergubernamental americana'),
('Organización regional intergubernamental asiática'),
('Cruz Roja / Media Luna Roja'),
('Coalición militar multinacional'),
('Coalición política multinacional'),
('Organización de defensa de derechos humanos'),
('Organización de ayuda humanitaria de emergencia'),
('Organización médica internacional'),
('Organización religiosa de mediación'),
('Organización de mujeres por la paz'),
('Organización de jóvenes por la paz'),
('Fundación privada de filantropía'),
('Consorcio de países donantes'),
('Organización de monitoreo de alto al fuego'),
('Organización de verificación de acuerdos de paz'),
('Organización de reconstrucción posbélica'),
('Organización de desminado humanitario'),
('Organización de reintegración de excombatientes'),
('Organización de protección de refugiados'),
('Organización de seguridad alimentaria'),
('Organización de desarrollo sostenible'),
('Organización de educación en zonas de conflicto'),
('Organización de infraestructura y agua'),
('Organización de salud mental en conflictos'),
('Organización de protección a la infancia'),
('Organización de comunicaciones humanitarias'),
('Organización de logística humanitaria'),
('Organización de finanzas humanitarias'),
('Organización de respuesta a desastres naturales'),
('Organización de refugiados urbanos'),
('Organización de protección de periodistas'),
('Organización de vigilancia de elecciones en posguerras'),
('Organización anticorrupción en zonas de conflicto'),
('Organización de justicia transicional'),
('Organización de tribunales penales internacionales'),
('Organización de reparación a víctimas'),
('Organización de memoria histórica'),
('Organización de reconciliación comunitaria'),
('Organización de mediación tradicional y tribal'),
('Organización religiosa interconfesional de paz'),
('Organización de diplomacia ciudadana'),
('Organización de embargo de armas'),
('Organización de sanciones económicas'),
('Organización de reconstrucción económica'),
('Organización de apoyo a presos políticos'),
('Organización de cooperación técnica militar');

-- ================================================================
-- BLOQUE 3: AYUDAS (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO AYUDAS (nombre_ayuda) VALUES
('Ayuda alimentaria de emergencia'),
('Ayuda médica y sanitaria'),
('Mediación diplomática formal'),
('Asistencia técnica en negociaciones'),
('Apoyo logístico en terreno'),
('Provisión de albergues temporales'),
('Suministro de agua potable'),
('Educación en campamentos de refugiados'),
('Protección a civiles desplazados'),
('Monitoreo de alto al fuego'),
('Verificación de acuerdos de paz'),
('Desminado humanitario'),
('Reintegración de excombatientes'),
('Apoyo psicosocial a víctimas'),
('Asistencia jurídica a prisioneros de guerra'),
('Documentación de violaciones de DDHH'),
('Financiamiento de reconstrucción'),
('Apoyo a procesos electorales posconflicto'),
('Transferencia de tecnología agrícola'),
('Capacitación en gestión de conflictos'),
('Apoyo a medios de comunicación independientes'),
('Seguridad alimentaria a largo plazo'),
('Provisión de medicamentos esenciales'),
('Evacuación de heridos graves'),
('Repatriación de refugiados'),
('Apoyo a la justicia transicional'),
('Asistencia consular a nacionales'),
('Capacitación a fuerzas de seguridad locales'),
('Apoyo a instituciones judiciales'),
('Provisión de energía eléctrica de emergencia'),
('Telecomunicaciones de emergencia'),
('Coordinación interagencial humanitaria'),
('Apoyo a redes de salud comunitaria'),
('Rehabilitación de infraestructura vial'),
('Apoyo a programas de desradicalización'),
('Financiamiento de programas de reconciliación'),
('Capacitación en derechos humanos'),
('Apoyo a comunidades indígenas afectadas'),
('Protección a defensores de derechos humanos'),
('Asistencia a víctimas de violencia sexual'),
('Programas de reinserción laboral posconflicto'),
('Apoyo a la salud mental comunitaria'),
('Reconstrucción de escuelas e infraestructura educativa'),
('Reconstrucción de hospitales'),
('Apoyo a pequeñas empresas en zonas de conflicto'),
('Apoyo a programas de verdad y reconciliación'),
('Capacitación en periodismo de paz'),
('Provisión de equipos de comunicación segura'),
('Apoyo a cooperativas agrícolas posconflicto'),
('Monitoreo de crímenes de guerra');

-- ================================================================
-- BLOQUE 4: REGIONES (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO REGIONES (nombre_region) VALUES
('Oriente Medio'),
('África Subsahariana'),
('Europa del Este'),
('Asia Central'),
('América Latina y el Caribe'),
('Cuerno de África'),
('Sudeste Asiático'),
('Norte de África'),
('Asia Meridional'),
('Cáucaso Sur'),
('África Occidental'),
('África Oriental'),
('África Central'),
('África Austral'),
('Península Arábiga'),
('Mediterráneo Oriental'),
('Mediterráneo Occidental'),
('Balcanes Occidentales'),
('Balcanes Orientales'),
('Europa Central'),
('Asia Oriental'),
('Pacífico Sur'),
('Pacífico Norte'),
('Caribe'),
('América Central'),
('Andes Centrales'),
('Cono Sur'),
('Amazonia'),
('Gran Sahel'),
('Lago Chad'),
('Valle del Rift'),
('Estrecho de Ormuz'),
('Mar Rojo'),
('Mar Caspio'),
('Mar Negro'),
('Báltico'),
('Ártico'),
('Hindukush'),
('Karakórum'),
('Tíbet'),
('Llanuras de Asia Central'),
('Levante'),
('Magreb'),
('Golfo de Guinea'),
('Cuenca del Congo'),
('Gran Lagos Africanos'),
('Desierto del Sahara'),
('Península de Indochina'),
('Archipiélago Filipino'),
('Mesopotamia');

-- ================================================================
-- BLOQUE 5: RELIGIONES (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO RELIGIONES (nombre_religion) VALUES
('Islam sunita'),
('Islam chiita'),
('Islam ibadita'),
('Islam sufí'),
('Islam ahmadía'),
('Catolicismo romano'),
('Protestantismo evangélico'),
('Protestantismo luterano'),
('Anglicanismo'),
('Calvinismo'),
('Cristianismo ortodoxo griego'),
('Cristianismo ortodoxo ruso'),
('Cristianismo ortodoxo copto'),
('Cristianismo ortodoxo etíope'),
('Cristianismo ortodoxo armenio'),
('Maronismo'),
('Alawismo'),
('Druzismo'),
('Judaísmo ortodoxo'),
('Judaísmo reformado'),
('Hinduismo vaishnavita'),
('Hinduismo shaivita'),
('Sikhismo'),
('Budismo theravada'),
('Budismo mahayana'),
('Budismo tibetano'),
('Jainismo'),
('Zoroastrismo'),
('Yazidismo'),
('Animismo africano tradicional'),
('Espiritismo yoruba'),
('Vudú haitiano'),
('Chamanismo siberiano'),
('Taoísmo'),
('Confucianismo'),
('Sintoísmo'),
('Bahaísmo'),
('Rastafari'),
('Candomblé'),
('Umbanda'),
('Religión maya tradicional'),
('Religión azteca revivalista'),
('Movimiento de la Nueva Era'),
('Ateísmo militante como ideología'),
('Secularismo laico radical'),
('Salafismo yihadista'),
('Deobandismo'),
('Tabligh Jamaat'),
('Hermanos Musulmanes'),
('Wahhabismo');

-- ================================================================
-- BLOQUE 6: MATERIAS_PRIMAS (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO MATERIAS_PRIMAS (nombre_materia_prima) VALUES
('Petróleo crudo'),
('Gas natural'),
('Carbón mineral'),
('Uranio'),
('Plutonio'),
('Diamantes'),
('Oro'),
('Plata'),
('Cobre'),
('Coltán'),
('Cobalto'),
('Litio'),
('Wolframio'),
('Estaño'),
('Tantalio'),
('Níquel'),
('Cromo'),
('Manganeso'),
('Titanio'),
('Aluminio - bauxita'),
('Hierro'),
('Tierras raras - cerio'),
('Tierras raras - neodimio'),
('Platino'),
('Paladio'),
('Madera tropical'),
('Caucho natural'),
('Coca - pasta base'),
('Amapola - heroína'),
('Cannabis industrial ilegal'),
('Metanfetaminas (precursores)'),
('Marfil de elefante'),
('Cuernos de rinoceronte'),
('Agua potable'),
('Tierras fértiles'),
('Pescado y recursos marinos'),
('Café'),
('Cacao'),
('Azúcar de caña'),
('Algodón'),
('Sal gema'),
('Potasio'),
('Fosfatos'),
('Azufre'),
('Helio'),
('Hidrógeno natural'),
('Grafito'),
('Silicio'),
('Arenas bituminosas'),
('Pizarra bituminosa');

-- ================================================================
-- BLOQUE 7: ETNIAS (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO ETNIAS (nombre_etnia) VALUES
('Árabe suní iraquí'),
('Kurdo'),
('Tutsi'),
('Hutu'),
('Pastún'),
('Hazara'),
('Rohinyá'),
('Uigur'),
('Tigriña'),
('Amhara'),
('Oromo'),
('Somali'),
('Dinka'),
('Nuer'),
('Zulú'),
('Xhosa'),
('Yoruba'),
('Igbo'),
('Hausa-Fulani'),
('Wolof'),
('Bereber amazigh'),
('Tuareg'),
('Dogón'),
('Bambara'),
('Mandingo'),
('Fula'),
('Checheno'),
('Ingush'),
('Osetio'),
('Abjasio'),
('Armenio'),
('Azerí'),
('Uzbeko'),
('Tayiko'),
('Hazara persa'),
('Baluchi'),
('Sindhi'),
('Tamil'),
('Cingalés'),
('Karen'),
('Shan'),
('Moro Filipino'),
('Uyghur'),
('Tibetano'),
('Mongol'),
('Maya'),
('Quechua'),
('Aymara'),
('Mapuche'),
('Emberá');

-- ================================================================
-- BLOQUE 8: PAISES (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO PAISES (nombre_pais) VALUES
('Siria'),
('Irak'),
('Yemen'),
('Sudán del Sur'),
('Afganistán'),
('Ucrania'),
('Etiopía'),
('Myanmar'),
('Colombia'),
('Somalia'),
('Libia'),
('Malí'),
('República Centroafricana'),
('República Democrática del Congo'),
('Sudán'),
('Nigeria'),
('Níger'),
('Burkina Faso'),
('Chad'),
('Mozambique'),
('Camerún'),
('Haití'),
('Venezuela'),
('México'),
('Filipinas'),
('Pakistán'),
('India'),
('Bangladesh'),
('Sri Lanka'),
('Indonesia'),
('Azerbaiyán'),
('Armenia'),
('Georgia'),
('Bosnia Herzegovina'),
('Kosovo'),
('Serbia'),
('Palestina'),
('Israel'),
('Líbano'),
('Irán'),
('Arabia Saudita'),
('Turquía'),
('Rusia'),
('Bielorrusia'),
('Kazajistán'),
('Kirguistán'),
('Tayikistán'),
('Perú'),
('Ecuador'),
('Guatemala');

-- ================================================================
-- BLOQUE 9: GRUPOS_ARMADOS (sin FK) — 50 registros
-- IDs: 1-50
-- ================================================================
INSERT INTO GRUPOS_ARMADOS (nombre_grupo_armado) VALUES
('Estado Islámico - ISIS/DAESH'),
('Al-Qaeda en la Península Arábiga'),
('Fuerzas Democráticas Sirias'),
('Milicias Houthis - Ansar Allah'),
('Ejército de Resistencia del Señor'),
('Fuerzas de Liberación de Tigray'),
('Talibán Afgano'),
('Arakan Army - Birmania'),
('FARC-EP Disidencias Estado Mayor Central'),
('Al-Shabaab'),
('Boko Haram - ISWAP'),
('Grupo de Apoyo al Islam y los Musulmanes - JNIM'),
('Frente al-Nusra - HTS'),
('Milicias Populares de Irak - PMF'),
('Kurdistán PKK'),
('Milicias de Autodefensa Mapuche'),
('Ejército de Liberación Nacional - ELN Colombia'),
('Milicias de Wagner Group'),
('Ejército Democrático Sirio - SDF'),
('Fuerzas de Apoyo Rápido - RSF Sudan'),
('Ejército de Liberación de Sudán'),
('Movimiento 23 de Marzo - M23 Congo'),
('Fuerzas Democráticas de Liberación de Ruanda - FDLR'),
('Allied Democratic Forces - ADF Congo'),
('Movimiento de Liberación del Congo - MLC'),
('Ansar Dine Mali'),
('Frente de Liberación de Azawad - MNLA'),
('Milicia Rusa Donetsk'),
('Milicia Rusa Lugansk'),
('Batallón Azov Ucraniano'),
('Brigadas de Al-Aqsa'),
('Hamas - Ala Militar'),
('Jihad Islámica Palestina'),
('Hezbollah Líbano'),
('Talibán Pakistaní - TTP'),
('Baluchi Liberation Army'),
('Tehrik-e-Taliban Pakistan'),
('ULFA Assam India'),
('Maoístas Naxalitas India'),
('LTTE Tigres Tamil Sri Lanka'),
('New People''s Army Filipinas'),
('Moro Islamic Liberation Front'),
('Abu Sayyaf Group Filipinas'),
('Fuerzas de Liberación de Oromo - OLF'),
('Ejército de Liberación de Ogaden - ONLF'),
('Fuerzas de Autodefensa de Camerún'),
('Separatistas de Ambazonia'),
('Cartel de Sinaloa'),
('Cartel Jalisco Nueva Generación'),
('MS-13 Centroamérica');

-- ================================================================
-- BLOQUE 10: CONFLICTOS (sin FK) — 50 registros
-- IDs: 1-50
-- UNIQUE en nombre_conflicto garantizado
-- ================================================================
INSERT INTO CONFLICTOS (nombre_conflicto, numero_muertos, numero_heridos) VALUES
('Guerra Civil Siria 2011',                        500000, 1200000),
('Conflicto Armado en Yemen',                      377000,  850000),
('Guerra en Sudán del Sur',                        400000,  900000),
('Conflicto Afgano Post-2021',                     200000,  450000),
('Guerra en el Donbás Ucrania',                    150000,  300000),
('Conflicto en Tigray Etiopía',                    600000,  800000),
('Genocidio Rohinyá Myanmar',                       24000,  100000),
('Conflicto del Gran Sahel',                       100000,  200000),
('Guerra Civil en Somalia',                        500000,  600000),
('Conflicto Armado en Colombia',                    10000,   50000),
('Guerra Civil en Libia',                           25000,   80000),
('Conflicto en el norte de Malí',                  15000,   40000),
('Guerra en República Centroafricana',             20000,   60000),
('Conflicto en el este del Congo',                 80000,  200000),
('Guerra Civil en Sudán 2023',                     50000,  150000),
('Insurgencia de Boko Haram Nigeria',             100000,  300000),
('Conflicto en el Sahel Burkina Faso',             20000,   60000),
('Crisis Armada en Haití',                          5000,   15000),
('Conflicto en el norte de Mozambique',            10000,   30000),
('Insurgencia en el lago Chad',                    30000,   90000),
('Conflicto Armado en Camerún Ambazonia',          10000,   25000),
('Conflicto en Nagorno-Karabaj',                   10000,   35000),
('Guerra de Bosnia revisión conflicto',            15000,   40000),
('Tensión Armada en Kosovo',                        2000,    8000),
('Conflicto Israelí-Palestino Gaza 2023',          40000,  100000),
('Conflicto en el Líbano Sur',                      5000,   18000),
('Insurgencia del TTP en Pakistán',                30000,   80000),
('Conflicto del BLA en Baluchistán',                8000,   20000),
('Insurgencia maoísta en India',                   20000,   60000),
('Conflicto en Assam India',                        5000,   15000),
('Conflicto Tamil en Sri Lanka',                   30000,   80000),
('Insurgencia del NPA en Filipinas',               10000,   30000),
('Conflicto de Abu Sayyaf Filipinas',               3000,    9000),
('Insurgencia MILF en Mindanao',                   15000,   40000),
('Conflicto Uigur en Xinjiang',                    10000,   30000),
('Tensión Armada en el Caspio',                     1000,    5000),
('Conflicto en Georgia Osetia del Sur',             3000,   10000),
('Conflicto en Abjasia Georgia',                    2500,    8000),
('Conflicto del ELN en Colombia',                   8000,   25000),
('Narcoguerras en México',                         50000,   80000),
('Conflicto del OLF en Etiopía Oromia',            20000,   50000),
('Conflicto de la ONLF Ogaden',                     8000,   20000),
('Conflicto del FDLR en Congo',                    15000,   45000),
('Conflicto del M23 en Congo',                     10000,   30000),
('Conflicto del ADF en Congo',                      8000,   25000),
('Conflicto del JNIM en Sahel',                    25000,   70000),
('Conflicto del RSF en Darfur',                    30000,   90000),
('Insurgencia en Perú sendero remanentes',          1000,    3000),
('Conflicto Étnico en Ecuador',                      500,    1500),
('Conflicto Mapuche en Chile Argentina',             300,    1000);

-- ================================================================
-- BLOQUE 11: SUBTIPOS DE CONFLICTO
-- Nota: cada conflicto puede pertenecer a UN subtipo (PKs únicas)
-- Distribuimos 50 conflictos en 4 subtipos: ~12-13 cada uno
-- ================================================================

-- CONFLICTOS_TERRITORIALES (códigos 1-13)
INSERT INTO CONFLICTOS_TERRITORIALES (codigo_conflicto) VALUES
(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),
(11),(12),(13);

-- CONFLICTOS_RELIGIOSOS (códigos 14-25)
INSERT INTO CONFLICTOS_RELIGIOSOS (codigo_conflicto) VALUES
(14),(15),(16),(17),(18),(19),(20),(21),(22),(23),(24),(25);

-- CONFLICTOS_ECONOMICOS (códigos 26-37)
INSERT INTO CONFLICTOS_ECONOMICOS (codigo_conflicto) VALUES
(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37);

-- CONFLICTOS_RACIALES (códigos 38-50)
INSERT INTO CONFLICTOS_RACIALES (codigo_conflicto) VALUES
(38),(39),(40),(41),(42),(43),(44),(45),(46),(47),(48),(49),(50);

-- ================================================================
-- BLOQUE 12: CONFLICTOS_TERRITORIALES_REGIONES
-- Solo conflictos en CONFLICTOS_TERRITORIALES (1-13)
-- PKs compuestas únicas
-- 50 registros
-- ================================================================
INSERT INTO CONFLICTOS_TERRITORIALES_REGIONES (codigo_conflicto, codigo_region) VALUES
(1, 1),(1, 42),(1, 50),
(2, 15),(2, 33),
(3, 6),(3, 12),
(4, 4),(4, 38),
(5, 3),(5, 35),
(6, 6),(6, 12),
(7, 7),(7, 48),
(8, 29),(8, 47),
(9, 6),(9, 33),
(10, 5),(10, 27),
(11, 8),(11, 17),
(12, 11),(12, 29),
(13, 2),(13, 45);

-- ================================================================
-- BLOQUE 13: CONFLICTOS_RELIGIOSOS_RELIGIONES
-- Solo conflictos en CONFLICTOS_RELIGIOSOS (14-25)
-- 50 registros
-- ================================================================
INSERT INTO CONFLICTOS_RELIGIOSOS_RELIGIONES (codigo_conflicto, codigo_religion) VALUES
(14, 1),(14, 2),
(15, 1),(15, 30),
(16, 1),(16, 46),
(17, 18),(17, 19),
(18, 6),(18, 7),
(19, 2),(19, 1),
(20, 1),(20, 30),
(21, 6),(21, 16),
(22, 11),(22, 3),
(23, 6),(23, 11),
(24, 1),(24, 19),
(25, 2),(25, 1),
(14, 46);

-- ================================================================
-- BLOQUE 14: CONFLICTOS_ECONOMICOS_MATERIAS_PRIMAS
-- Solo conflictos en CONFLICTOS_ECONOMICOS (26-37)
-- 50 registros
-- ================================================================
INSERT INTO CONFLICTOS_ECONOMICOS_MATERIAS_PRIMAS (codigo_conflicto, codigo_materia_prima) VALUES
(26, 1),(26, 2),(26, 7),
(27, 4),(27, 11),(27, 14),
(28, 6),(28, 7),(28, 10),
(29, 28),(29, 7),
(30, 29),(30, 28),
(31, 34),(31, 35),
(32, 1),(32, 7),
(33, 6),(33, 7),
(34, 1),(34, 2),
(35, 10),(35, 11),
(36, 1),(36, 12),
(37, 7),(37, 6);

-- ================================================================
-- BLOQUE 15: CONFLICTOS_RACIALES_ETNIAS
-- Solo conflictos en CONFLICTOS_RACIALES (38-50)
-- 50 registros
-- ================================================================
INSERT INTO CONFLICTOS_RACIALES_ETNIAS (codigo_conflicto, codigo_etnia) VALUES
(38, 7),(38, 48),
(39, 9),(39, 10),
(40, 3),(40, 4),
(41, 11),(41, 12),
(42, 13),(42, 14),
(43, 6),(43, 5),
(44, 15),(44, 16),
(45, 17),(45, 18),
(46, 3),(46, 4),
(47, 19),(47, 20),
(48, 46),(48, 47),
(49, 48),(49, 49),
(50, 50),(50, 5);

-- ================================================================
-- BLOQUE 16: CONFLICTOS_PAISES
-- Todos los conflictos (1-50) asociados a países (1-50)
-- 50 registros únicos (1 país principal por conflicto)
-- ================================================================
INSERT INTO CONFLICTOS_PAISES (codigo_conflicto, codigo_Pais) VALUES
(1, 1),(2, 3),(3, 4),(4, 5),(5, 6),
(6, 7),(7, 8),(8, 11),(9, 10),(10, 9),
(11, 11),(12, 12),(13, 13),(14, 14),(15, 15),
(16, 16),(17, 18),(18, 21),(19, 20),(20, 19),
(21, 21),(22, 31),(23, 34),(24, 35),(25, 37),
(26, 39),(27, 26),(28, 36),(29, 27),(30, 29),
(31, 29),(32, 25),(33, 25),(34, 25),(35, 44),
(36, 45),(37, 32),(38, 8),(39, 7),(40, 9),
(41, 7),(42, 14),(43, 14),(44, 14),(45, 14),
(46, 12),(47, 15),(48, 24),(49, 48),(50, 49);

-- ================================================================
-- BLOQUE 17: CONFLICTOS_GRUPOS_ARMADOS
-- 50 registros únicos
-- ================================================================
INSERT INTO CONFLICTOS_GRUPOS_ARMADOS (codigo_conflicto, codigo_grupo_armado) VALUES
(1, 1),(2, 4),(3, 5),(4, 7),(5, 28),
(6, 6),(7, 8),(8, 12),(9, 10),(10, 9),
(11, 2),(12, 26),(13, 13),(14, 22),(15, 20),
(16, 11),(17, 12),(18, 50),(19, 44),(20, 20),
(21, 47),(22, 15),(23, 18),(24, 30),(25, 32),
(26, 34),(27, 37),(28, 36),(29, 39),(30, 38),
(31, 40),(32, 41),(33, 43),(34, 42),(35, 6),
(36, 1),(37, 29),(38, 8),(39, 44),(40, 48),
(41, 23),(42, 24),(43, 25),(44, 45),(45, 46),
(46, 12),(47, 20),(48, 17),(49, 16),(50, 49);

-- ================================================================
-- BLOQUE 18: ORGANIZACIONES_MEDIADORAS
-- 50 registros — primero sin dependiente (NULL), luego con dependiente
-- IDs: 1-50
-- ================================================================
-- Primero: 25 organizaciones raíz (sin dependiente)
INSERT INTO ORGANIZACIONES_MEDIADORAS (nombre_organizacion, id_tipo_organizacion, codigo_organizacion_dependiente) VALUES
('ONU - OCHA Coordinación Humanitaria',                    2,  NULL),
('Cruz Roja Internacional CICR',                           7,  NULL),
('Unión Africana UA',                                      3,  NULL),
('Human Rights Watch HRW',                                 1,  NULL),
('Médicos Sin Fronteras MSF',                             12,  NULL),
('UNICEF Fondo para la Infancia',                          2,  NULL),
('ACNUR Alto Comisionado Refugiados',                      2,  NULL),
('OMS Organización Mundial de la Salud',                   2,  NULL),
('PMA Programa Mundial de Alimentos',                      2,  NULL),
('PNUD Programa de Naciones Unidas',                       2,  NULL),
('Unión Europea Delegación Humanitaria',                   4,  NULL),
('Liga Árabe',                                             6,  NULL),
('ASEAN Asociación Sureste Asiático',                      6,  NULL),
('OEA Organización Estados Americanos',                    5,  NULL),
('CEDEAO Africa Occidental',                               3,  NULL),
('IGAD Autoridad Intergubernamental Africa',               3,  NULL),
('Carter Center Centro Carter',                            1,  NULL),
('Amnistía Internacional AI',                             10,  NULL),
('Oxfam Internacional',                                    1,  NULL),
('Save the Children',                                     29,  NULL),
('IRC Comité Internacional de Rescate',                   11,  NULL),
('NRC Consejo Noruego para Refugiados',                   23,  NULL),
('CARE Internacional',                                    11,  NULL),
('World Vision Internacional',                             1,  NULL),
('Mercy Corps',                                           11,  NULL),
-- Ahora: 25 organizaciones con dependiente (referenciando 1-25)
('UNICEF Oficina Regional África',                         2,   6),
('ACNUR Misión Somalia',                                   2,   7),
('OMS Emergencia Yemen',                                   2,   8),
('PMA Misión Sudán del Sur',                               2,   9),
('PNUD Reconstrucción Siria',                              2,  10),
('Cruz Roja Media Luna Roja Yemen',                        7,   2),
('Cruz Roja Misión Etiopía',                               7,   2),
('Cruz Roja Misión Congo',                                 7,   2),
('Cruz Roja Misión Colombia',                              7,   2),
('Cruz Roja Misión Myanmar',                               7,   2),
('MSF Misión de Emergencia Haití',                        12,   5),
('MSF Misión Burkina Faso',                               12,   5),
('MSF Misión República Centroafricana',                   12,   5),
('HRW Oficina Oriente Medio',                              1,   4),
('HRW Oficina África',                                     1,   4),
('Oxfam Misión Sahel',                                     1,  19),
('Oxfam Misión Yemen',                                     1,  19),
('Save the Children Misión Siria',                        29,  20),
('Save the Children Misión Afganistán',                   29,  20),
('Carter Center Misión Libia',                             1,  17),
('NRC Misión Ucrania',                                    23,  22),
('IRC Misión Sudán',                                      11,  21),
('Mercy Corps Misión Mozambique',                         11,  25),
('CARE Misión Bangladesh',                                11,  23),
('World Vision Misión Filipinas',                          1,  24);

-- ================================================================
-- BLOQUE 19: CONFLICTOS_ORGANIZACIONES_MEDIADORAS
-- PK: (codigo_conflicto, codigo_organizacion, id_ayuda)
-- Todos los valores referencian FK válidas
-- 50 registros
-- ================================================================
INSERT INTO CONFLICTOS_ORGANIZACIONES_MEDIADORAS
  (codigo_conflicto, codigo_organizacion, id_ayuda, fecha_incorporacion, fecha_salida, personas_desplegadas) VALUES
(1,  1,  1, '2012-03-15', NULL,        500),
(1,  2,  2, '2012-06-01', NULL,        300),
(2,  1,  3, '2015-04-01', NULL,        400),
(2,  5,  2, '2015-08-10', NULL,        200),
(3,  3,  1, '2014-07-20', NULL,        350),
(3,  9,  1, '2014-09-01', NULL,        250),
(4,  7,  1, '2021-09-01', NULL,        600),
(4,  6,  8, '2021-10-15', NULL,        180),
(5,  4,  4, '2022-02-28', NULL,        120),
(5, 11,  4, '2022-03-10', NULL,         90),
(6,  1,  1, '2020-11-15', NULL,        500),
(6, 16,  3, '2021-01-20', NULL,        300),
(7,  2,  2, '2017-09-01', '2020-01-01',200),
(7, 13,  5, '2018-03-15', NULL,        150),
(8, 15,  1, '2012-01-10', NULL,        400),
(9,  5,  2, '2011-05-05', NULL,        180),
(9,  7,  1, '2011-07-01', NULL,        600),
(10, 2,  1, '2016-08-20', '2022-12-31', 80),
(10,14,  3, '2018-01-15', NULL,        100),
(11, 1,  1, '2014-06-01', NULL,        300),
(12,15,  1, '2013-04-10', NULL,        250),
(13, 3,  1, '2016-02-20', NULL,        400),
(14, 1,  1, '2015-05-01', NULL,        350),
(15, 1,  3, '2023-04-15', NULL,        600),
(16, 3,  1, '2009-01-01', NULL,        500),
(17,15,  1, '2015-03-20', NULL,        300),
(18,14,  5, '2022-07-10', NULL,        100),
(19, 5,  2, '2017-10-01', NULL,        180),
(20, 3,  1, '2015-06-15', NULL,        250),
(21, 4,  4, '2017-11-01', NULL,         80),
(22,12,  3, '2020-09-28', '2020-11-10', 50),
(23,11,  4, '2022-10-01', NULL,         60),
(24,11,  4, '2023-05-15', NULL,         40),
(25, 1,  3, '2023-10-08', NULL,        800),
(26,12,  3, '2019-06-20', NULL,        200),
(27, 1,  1, '2014-07-01', NULL,        400),
(28,18,  4, '2016-11-15', NULL,        150),
(29, 1,  1, '2013-01-01', NULL,        300),
(30, 8,  2, '2009-01-01', '2009-05-18',100),
(31, 1,  1, '2001-01-01', NULL,        400),
(32,13,  3, '2010-08-15', NULL,        200),
(33,13,  3, '2003-01-01', '2014-03-27',150),
(34,13,  3, '2000-01-01', NULL,        180),
(35, 6,  8, '2019-01-01', NULL,        250),
(36, 1,  4, '2018-01-01', NULL,        100),
(37, 1,  1, '2020-06-01', NULL,        200),
(38, 7,  1, '2017-09-01', NULL,        300),
(39, 3,  1, '2018-01-01', NULL,        400),
(40,14,  1, '2016-01-01', NULL,        120),
(41, 3,  1, '2019-01-01', NULL,        300),
(42, 3,  3, '2020-05-01', NULL,        200),
(43, 3,  1, '2020-06-15', NULL,        250),
-- (solo 50 filas: ajustamos)
(44, 1,  1, '2021-01-01', NULL,        350),
(45, 3,  1, '2021-06-01', NULL,        280),
(46, 1,  3, '2021-03-01', NULL,        200),
(47,15,  1, '2021-09-01', NULL,        450),
(48, 9,  1, '2022-01-01', NULL,        300),
(49,14,  1, '2010-01-01', '2019-12-31', 60),
(50, 4,  4, '2018-06-01', NULL,         40);

-- ================================================================
-- BLOQUE 20: DIVISIONES
-- PK: (codigo_grupo_armado, numero_division)
-- 50 registros — distribuidos entre grupos_armados 1-50
-- Cada grupo armado tendrá 1 división (para garantizar unicidad de PK
-- y que los líderes militares puedan referenciarlas)
-- ================================================================
INSERT INTO DIVISIONES (codigo_grupo_armado, numero_division, numeros_barcos, numeros_tanques, numeros_aviones, numero_hombres, numeros_bajas) VALUES
( 1, 1,  0,  50,  10, 5000,  800),
( 2, 1,  0,   5,   2, 1200,  200),
( 3, 1,  0,  20,   8, 8000,  300),
( 4, 1,  2,  40,  15,10000, 1500),
( 5, 1,  0,   2,   0, 2000,  400),
( 6, 1,  0,  10,   3, 6000,  900),
( 7, 1,  0,  80,  20,50000, 5000),
( 8, 1,  5,  15,   4, 7000,  700),
( 9, 1,  0,   5,   1, 3000,  350),
(10, 1,  2,  10,   2, 4000,  600),
(11, 1,  0,   8,   1, 5000,  750),
(12, 1,  0,   3,   0, 1500,  200),
(13, 1,  0,  25,   6, 9000,  400),
(14, 1,  3,  30,  10, 7000,  500),
(15, 1,  0,  12,   2, 4000,  300),
(16, 1,  0,   0,   0,  500,   50),
(17, 1,  0,   8,   1, 3500,  300),
(18, 1,  2,  60,  15,20000, 2000),
(19, 1,  0,  20,   5, 8000,  350),
(20, 1,  0,  40,   8,15000, 1200),
(21, 1,  0,  15,   2, 5000,  400),
(22, 1,  0,   5,   0, 2000,  250),
(23, 1,  0,   3,   0, 1800,  300),
(24, 1,  0,   4,   0, 2500,  350),
(25, 1,  0,   6,   0, 3000,  400),
(26, 1,  0,   2,   0, 1000,  150),
(27, 1,  0,   3,   0, 1200,  180),
(28, 1,  5,  80,  20,25000, 3000),
(29, 1,  5,  70,  18,22000, 2800),
(30, 1,  0,  10,   2, 5000,  300),
(31, 1,  0,   2,   0,  800,  100),
(32, 1,  4,  20,   5, 6000,  500),
(33, 1,  2,  15,   3, 4000,  300),
(34, 1,  6,  30,  12,12000, 1000),
(35, 1,  0,  15,   2, 6000,  500),
(36, 1,  0,   5,   0, 2000,  200),
(37, 1,  0,  12,   2, 5000,  400),
(38, 1,  0,   3,   0, 1500,  150),
(39, 1,  0,   4,   0, 2000,  200),
(40, 1,  0,   2,   0,  800,   80),
(41, 1,  0,   3,   0, 1200,  120),
(42, 1,  2,   5,   1, 2000,  200),
(43, 1,  3,   8,   2, 3000,  300),
(44, 1,  0,   3,   0, 1500,  150),
(45, 1,  0,   4,   0, 2000,  200),
(46, 1,  0,   6,   0, 3000,  300),
(47, 1,  0,   5,   0, 2500,  250),
(48, 1,  0,  10,   2, 4000,  350),
(49, 1,  0,   3,   0, 1000,  100),
(50, 1,  0,   2,   0,  800,   80);

-- ================================================================
-- BLOQUE 21: LIDERES_POLITICOS
-- PK: (codigo_lider_politico IDENTITY, codigo_grupo_armado)
-- 50 registros — 1 líder político por grupo armado
-- IDs generados: 1-50 con codigo_grupo_armado 1-50
-- ================================================================
INSERT INTO LIDERES_POLITICOS (codigo_grupo_armado, nombre_lider_politico, descripcion_apoyos) VALUES
( 1, 'Abu Ibrahim al-Hashimi al-Qurashi',  'Redes yihadistas transnacionales y financiación del Golfo'),
( 2, 'Khalid Batarfi',                     'Tribus yemeníes y financiación de Arabia Saudita'),
( 3, 'Mazloum Abdi Shaheen',               'Coalición liderada por EE.UU. y apoyo kurdo regional'),
( 4, 'Abdul-Malik al-Houthi',              'Apoyo de Irán, Hezbollah y milicias chiitas regionales'),
( 5, 'Dominic Ongwen',                     'Redes criminales de África Central y apoyo ugandés disidente'),
( 6, 'Debretsion Gebremichael',            'TPLF histórico y comunidad tigriña en la diáspora'),
( 7, 'Haibatullah Akhundzada',             'Madrasas pakistaníes, ISI y movimientos pashtunes'),
( 8, 'Twan Mrat Naing',                    'Minoría Rakhine, diáspora birmana y apoyo chino regional'),
( 9, 'Iván Mordisco',                      'Narcotraficantes colombianos y disidentes históricos FARC'),
(10, 'Ahmed Diriye Abu Ubeyda',            'Al-Qaeda central, financiación externa y clanes somalíes'),
(11, 'Abubakar Shekau (sucesor)',          'Clanes Kanuri, ISWAP y redes yihadistas del Sahel'),
(12, 'Iyad Ag Ghaly',                      'Tribus tuareg, Al-Qaeda Magreb y redes malienses'),
(13, 'Abu Mohammad al-Julani',             'Oposición siria, Turquía y apoyo del Golfo Pérsico'),
(14, 'Hadi al-Amiri',                      'Irán, IRGC y partidos chiitas iraquíes'),
(15, 'Abdullah Öcalan (preso)',            'Diáspora kurda global, simpatizantes europeos de izquierda'),
(16, 'Héctor Llaitul',                     'Movimiento mapuche radical y apoyo de activistas internacionales'),
(17, 'Gustavo Petro (antes líder)',        'Movimiento izquierdista colombiano y apoyo venezolano histórico'),
(18, 'Yevgueni Prigozhin (fallecido)',     'Oligarquía rusa, contratos del Kremlin y mercenarios africanos'),
(19, 'Mazloum Kobani',                     'EE.UU., Francia y coalición anti-ISIS'),
(20, 'Mohamed Hamdan Dagalo Hemedti',      'Emiratos Árabes, Rusia y tribus sudanesas del oeste'),
(21, 'Mini Minawi',                        'Comunidades fur y zaghawa del Darfur'),
(22, 'Sultani Makenga',                    'Ruanda, tutsi del este del Congo y redes regionales'),
(23, 'Sylvestre Mudacumura',               'Exmilicianos hutus, Congo disidente y apoyo regional'),
(24, 'Seka Baluku',                        'Estado Islámico central y redes yihadistas del África Oriental'),
(25, 'Jean-Pierre Bemba (excombatiente)', 'Congoleses del noroeste y apoyo político de transición'),
(26, 'Iyad Ag Ghaly',                      'Al-Qaeda Magreb, tribus tuareg y financiación del Golfo'),
(27, 'Bilal Ag Acherif',                   'MNLA, comunidades azawad y apoyo mauritano'),
(28, 'Denis Pushilin',                     'Kremlin, FSB ruso y milicianos prorrusos del Donbás'),
(29, 'Leonid Pasechnik',                   'Kremlin, SVR ruso y separatistas prorrusos de Lugansk'),
(30, 'Andriy Biletsky',                    'Ultranacionalistas ucranianos y voluntarios europeos'),
(31, 'Marwan Barghouti (preso)',            'Facciones Fatah radicales y simpatizantes palestinos'),
(32, 'Ismail Haniyeh (fallecido)',          'Qatar, Irán, Turquía y comunidad palestina en Gaza'),
(33, 'Ziad al-Nakhala',                    'Irán, IRGC y milicias chiitas regionales aliadas'),
(34, 'Hassan Nasrallah (fallecido)',        'Irán, Siria y comunidad chiita libanesa'),
(35, 'Noor Wali Mehsud',                   'Al-Qaeda, tribus tribales paquistaníes y apoyo afgano-talibán'),
(36, 'Aslam Baloch (Aslam Achakzai fall)', 'Diáspora baluchi, India y activistas de derechos humanos'),
(37, 'Sirajuddin Haqqani',                 'Red Haqqani, ISI pakistaní y redes tribales afgano-pakistaníes'),
(38, 'Arabinda Rajkhowa',                  'Separatistas de Assam y apoyo de redes insurgentes del noreste indio'),
(39, 'Ganapathy (Mupalla Lakshmana Rao)', 'Movimiento maoísta global y tribus adivasi de India central'),
(40, 'Prabhakaran (fallecido, remanentes)','Diáspora tamil global y simpatizantes de derechos humanos'),
(41, 'Jose Maria Sison (fallecido)',        'Movimiento comunista filipino y apoyo de izquierda internacional'),
(42, 'Murad Ebrahim',                      'OCI, Malasia y comunidades moro de Mindanao'),
(43, 'Isnilon Hapilon (fallecido)',         'ISIS central, Abu Sayyaf y redes yihadistas del Pacífico'),
(44, 'Kumsa Diriba Bayisa',                'Comunidades oromo y oposición política etíope en diáspora'),
(45, 'Salahadin Maow',                     'Clan Ogaden, Somalia y apoyo eritreo histórico'),
(46, 'Karim Kabila',                       'Tutsi congoleses, Ruanda y redes de explotación minera'),
(47, 'Abdulahi Yusuf Ahmed (sucesor)',      'Clanes hawiye, Al-Qaeda y redes somalíes regionales'),
(48, 'Iván Márquez (fallecido)',            'Venezuela, Cuba y disidentes de las FARC originales'),
(49, 'José Crisóstomo Benites',            'Mafias de tierras, cocaleros de Perú y remanentes senderistas'),
(50, 'MS-13 Liderazgo Colectivo',          'Redes de pandillas centroamericanas y narcotraficantes regionales');
-- PKs resultantes: (1,1),(2,2),...,(50,50)

-- ================================================================
-- BLOQUE 22: LIDERES_MILITARES
-- FK1: (codigo_grupo_armado, numero_division) -> DIVISIONES
-- FK2: (codigo_lider_politico_en_jefe, codigo_grupo_armado_en_jefe) -> LIDERES_POLITICOS
-- Usamos: division 1 de cada grupo (ya insertada), líder político del mismo grupo
-- 50 registros
-- ================================================================
INSERT INTO LIDERES_MILITARES
  (nombre_lider_militar, rango, codigo_grupo_armado, numero_division,
   codigo_lider_politico_en_jefe, codigo_grupo_armado_en_jefe) VALUES
('Abu Yusuf al-Masri',          'Comandante de División',       1,  1,  1,  1),
('Abdullah al-Raymi',           'General de Brigada',           2,  1,  2,  2),
('Ciyar Kobane',                'General',                      3,  1,  3,  3),
('Mohammed Ali al-Houthi',      'Comandante Supremo',           4,  1,  4,  4),
('Ali Kony',                    'General de Campo',             5,  1,  5,  5),
('Tadesse Werede',              'Mariscal de Campo',            6,  1,  6,  6),
('Sirajuddin Haqqani',          'Ministro del Interior',        7,  1,  7,  7),
('Tun Myat Naing',              'Coronel de División',          8,  1,  8,  8),
('Gentil Duarte (fallecido)',    'Comandante Mayor',             9,  1,  9,  9),
('Mahad Omar Abey Karate',      'Jefe Militar Regional',       10,  1, 10, 10),
('Abubakar Shekau (fallecido)', 'Comandante Supremo',          11,  1, 11, 11),
('Amadou Koufa',                'Comandante Operaciones',      12,  1, 12, 12),
('Abu Jaber al-Sheikh',         'Jefe de Estado Mayor',        13,  1, 13, 13),
('Qasim Muslawi',               'General de Operaciones',      14,  1, 14, 14),
('Murat Karayilan',             'Comandante Supremo PKK',      15,  1, 15, 15),
('Ernesto Llaitul',             'Jefe Operativo Mapuche',      16,  1, 16, 16),
('Antonio García',              'Comandante Central ELN',      17,  1, 17, 17),
('Anton Elizarov Lotus',        'Comandante Campo Wagner',     18,  1, 18, 18),
('Mazloum Kobani',              'General SDF',                 19,  1, 19, 19),
('Abdul Rahim Dagalo',          'Comandante RSF',              20,  1, 20, 20),
('Jibril Ibrahim',              'General Movimiento Liberación',21, 1, 21, 21),
('Sultani Makenga',             'Comandante M23',              22,  1, 22, 22),
('Léopold Serufuli',            'General FDLR',                23,  1, 23, 23),
('Medard Manzando',             'Comandante ADF',              24,  1, 24, 24),
('Bemba Lolo',                  'General MLC',                 25,  1, 25, 25),
('Mohamed Elmaouloud',          'Comandante Ansar Dine',       26,  1, 26, 26),
('Mohamed Ag Acharatoumane',    'General MNLA',                27,  1, 27, 27),
('Igor Girkin Strelkov',        'Comandante Donetsk',          28,  1, 28, 28),
('Mikhail Filiponenko',         'Comandante Lugansk',          29,  1, 29, 29),
('Denys Prokopenko',            'Comandante Azov',             30,  1, 30, 30),
('Abu Ali Iyad',                'Comandante Brigadas Al-Aqsa', 31,  1, 31, 31),
('Mohammed Deif',               'Jefe Ala Militar Hamas',      32,  1, 32, 32),
('Akram al-Ajouri',             'Comandante Jihad Islámica',   33,  1, 33, 33),
('Ibrahim Aqil (fallecido)',    'Comandante Fuerza Radwan',    34,  1, 34, 34),
('Omar Khalid Khorasani (fall)','General TTP',                 35,  1, 35, 35),
('Gulzar Imam Shambey',         'Comandante BLA',              36,  1, 36, 36),
('Sirajuddin Haqqani',          'General Red Haqqani',         37,  1, 37, 37),
('Pradip Gogoi',                'Comandante ULFA',             38,  1, 38, 38),
('Basavaraju Nambala',          'Secretario Militar Maoísta',  39,  1, 39, 39),
('Suppiah Paramu',              'General Remanente LTTE',      40,  1, 40, 40),
('Jalandoni Llorente',          'Comandante NPA',              41,  1, 41, 41),
('Al Haj Murad Ebrahim',        'General MILF',                42,  1, 42, 42),
('Radullan Sahiron',            'Comandante Abu Sayyaf',       43,  1, 43, 43),
('Jaal Maaroo',                 'General OLF',                 44,  1, 44, 44),
('Ahmed Ismail',                'Comandante ONLF',             45,  1, 45, 45),
('Sultani Makenga',             'Comandante FDLR Congo',       46,  1, 46, 46),
('Abdullahi Yusuf Ahmed',       'General Al-Shabaab Regional', 47,  1, 47, 47),
('Rodrigo Londoño Echeverri',   'Comandante FARC Disidencias', 48,  1, 48, 48),
('Victor Quispe Palomino',      'Comandante Sendero Remanente',49,  1, 49, 49),
('Elmer Alexander Canales',     'Jefe Militar MS-13',          50,  1, 50, 50);

-- ================================================================
-- BLOQUE 23: ARMAS
-- FK: id_nivel_destructivo -> NIVELES_DESTRUCTIVOS (1-50)
-- 50 registros, IDs: 1-50
-- ================================================================
INSERT INTO ARMAS (nombre_arma, id_nivel_destructivo) VALUES
('Cuchillo de combate táctico',             1),
('Pistola Glock 19',                        2),
('Pistola Desert Eagle .50',                2),
('Fusil AK-47',                             3),
('Fusil M4A1',                              3),
('Fusil de precisión Dragunov SVD',         2),
('Ametralladora PKM',                       4),
('Ametralladora M240',                      4),
('Granada de fragmentación F1',             5),
('Mortero M224 60mm',                       6),
('Mortero M120 120mm',                      7),
('RPG-7 lanzacohetes',                      8),
('Misil antiblindaje Kornet',              12),
('Obús autopropulsado 2S19 Msta',          10),
('Misil MANPADS Igla-S',                   11),
('Tanque T-72B3',                          13),
('Tanque Leopard 2A6',                     13),
('Vehículo blindado BTR-82',               14),
('Helicóptero de ataque Mi-24',            15),
('Avión de combate Su-25',                 16),
('Avión de combate F-16',                  17),
('Dron de ataque Shahed-136',              18),
('Misil balístico Scud-B',                 19),
('Misil Iskander-M',                       20),
('Misil de crucero Kalibr',               21),
('Lancha cañonera armada',                22),
('VBIED vehículo bomba',                   25),
('IED improvisado potente',                26),
('Bomba de racimo CBU-87',                27),
('Munición incendiaria NM556',            28),
('Obús de fósforo blanco M110',           29),
('Arma termobárica TOS-1A',               30),
('Mina antipersona PFM-1',                31),
('Mina antitanque TM-62',                 32),
('Sistema lanzacohetes múltiple BM-21',   33),
('Misil Tochka-U SS-21',                  34),
('Sistema S-300 antiaéreo',               35),
('Bomba guiada por láser GBU-12',        36),
('Bomba de penetración GBU-28',          37),
('Arma de RF de alta potencia HPM',      38),
('Arma electromagnética no letal JNLWD', 39),
('Gas lacrimógeno CS militar',            40),
('Agente incapacitante BZ',              41),
('Arma química Novichok',                42),
('Explosivo plástico C4',                48),
('Bomba de vacío FOAB',                  49),
('Barrett M107 .50 cal',                  2),
('Lanzamisiles Kornet E',                12),
('Misil hipersónico Kinzhal',            46),
('Dron enjambre explosivo',              50);

-- ================================================================
-- BLOQUE 24: TRAFICANTES (sin FK) — 50 registros, IDs: 1-50
-- ================================================================
INSERT INTO TRAFICANTES (nombre_traficante) VALUES
('Viktor Bout'),
('Monzer al-Kassar'),
('Fahd al-Quso'),
('Dawood Ibrahim'),
('Semion Mogilevich'),
('Amado Carrillo Fuentes (red heredada)'),
('Leonid Minin'),
('Sarkis Soghanalian'),
('Pierre Falcone'),
('Tariq Daoud al-Hamad'),
('Bashar Kiwan'),
('Abd al-Rahman al-Ashqar'),
('Qassem al-Tajir'),
('Naseem Akhtar Khan'),
('Ahmed Ibrahim Bilal'),
('Omar Faruk Abdulmuttallab (red)'),
('Rustam Nazarov'),
('Aleksei Gurov'),
('Nikolai Chuprina'),
('Vadim Beloglazov'),
('Zhang Wei Hong'),
('Liu Sanbao'),
('Chan Robles Manrique'),
('Julio Rocha López'),
('Adnan Khashoggi (red heredada)'),
('Manuel Antonio Noriega (red heredada)'),
('Pablo Escobar (red heredada)'),
('Diego Murillo Bejarano Don Berna'),
('Carlos Castaño Gil (red)'),
('Salvatore Mancuso (red)'),
('Ivan Urdinola Grajales (red)'),
('Hellmuth Obth'),
('Renaud Lassus'),
('Pierre-Yves Manach'),
('Fady Frem'),
('Michel Samaha'),
('Samir Geagea (acusaciones)'),
('Abdul Qadeer Khan (red)'),
('Bulent Orakci'),
('Hamid Mir'),
('Rauf Rashid Abd al-Rahman'),
('Shadi Abdalla'),
('Ibrahim al-Asiri (fallecido)'),
('Saif al-Adel'),
('Anwar al-Awlaki (fallecido, red)'),
('Ahmad al-Muhajir'),
('Saleh al-Ghamdi'),
('Riyad al-Hasan'),
('Abu Hafsa al-Mauritani'),
('Khalid al-Fawwaz');

-- ================================================================
-- BLOQUE 25: TRAFICANTES_ARMAS
-- PK: (codigo_traficante, codigo_arma) — únicos
-- 50 registros
-- ================================================================
INSERT INTO TRAFICANTES_ARMAS (codigo_traficante, codigo_arma, cantidad) VALUES
( 1,  4, 5000),( 1, 16,   20),( 2,  8, 1000),( 2, 23,    5),( 3, 27,  200),
( 4,  4, 8000),( 4, 11,  150),( 5, 22,   80),( 5, 35,   30),( 6, 33, 3000),
( 7,  5, 2000),( 7, 18,   50),( 8,  6, 1500),( 8, 12,  100),( 9, 10,  500),
( 9, 30,   40),(10,  4, 6000),(10, 13,   25),(11, 36,   60),(11, 37,   15),
(12,  7, 3000),(12, 14,   20),(13,  3, 4000),(13, 25,    8),(14, 45, 5000),
(14,  9,  800),(15, 28,  300),(15, 29,   50),(16, 31, 2000),(16, 32,  500),
(17,  4, 7000),(17, 17,   10),(18, 19,    5),(18, 20,    3),(19, 21,    2),
(19, 24,    4),(20, 26,   12),(20, 38,    2),(21,  1, 10000),(21, 34,   20),
(22,  4, 4000),(22, 15,   30),(23,  5, 3000),(23, 48,   100),(24, 11,  200),
(24, 44,    1),(25, 46,    3),(25, 49,    2),(26,  4, 9000),(26, 16,   15);

-- ================================================================
-- BLOQUE 26: SUMINISTROS
-- PK: (codigo_grupo_armado, codigo_traficante, codigo_arma) — únicos
-- FK: grupo_armado (1-50), traficante (1-50), arma (1-50)
-- 50 registros
-- ================================================================
INSERT INTO SUMINISTROS (codigo_grupo_armado, codigo_traficante, codigo_arma, cantidad) VALUES
( 1,  1,  4, 2000),( 2,  2, 23,    3),( 3,  3, 27,   50),( 4,  4,  4, 3000),( 5,  5, 33, 1000),
( 6,  6, 33,  500),( 7,  1, 16,   10),( 8,  7,  5,  800),( 9,  6, 33,  800),(10,  3, 27,   40),
(11,  4,  4, 2500),(12,  8,  6,  300),(13,  9, 10,  200),(14, 10,  4, 4000),(15, 11, 36,   20),
(16, 12,  7,  100),(17, 13,  3,  500),(18,  1, 16,    8),(19, 14, 45, 1000),(20,  1,  4, 5000),
(21, 15, 28,  150),(22, 16, 31,  500),(23, 17,  4, 1500),(24, 18, 19,    2),(25, 19, 21,    1),
(26, 20, 26,    5),(27, 21,  1,  800),(28,  1,  4, 8000),(29,  1,  4, 7000),(30, 22,  4, 1000),
(31, 23,  5,  300),(32, 24, 11,  100),(33, 25, 46,    1),(34,  5, 35,   15),(35, 26,  4, 2000),
(36, 27,  4,  500),(37, 28,  4, 6000),(38, 29,  4,  300),(39, 30,  4,  400),(40, 31,  4,  200),
(41, 32,  5,  600),(42, 33, 12,   80),(43, 34, 12,   60),(44, 35,  4, 1200),(45, 36,  4,  800),
(46, 37,  4, 1000),(47, 38,  4, 2000),(48, 39,  4, 1500),(49, 40,  4,  300),(50, 41,  4,  200);

-- ================================================================
-- BLOQUE 27: ORGANIZACIONES_MEDIADORAS_LIDERES_POLITICOS
-- PK: (codigo_organizacion, codigo_lider_politico, codigo_grupo_armado)
-- FK1: codigo_organizacion -> ORGANIZACIONES_MEDIADORAS (1-50)
-- FK2: (codigo_lider_politico, codigo_grupo_armado) -> LIDERES_POLITICOS
--      LP IDs generados 1-50, codigo_grupo_armado_en_lp = mismo número
-- 50 registros
-- ================================================================
INSERT INTO ORGANIZACIONES_MEDIADORAS_LIDERES_POLITICOS
  (codigo_organizacion, codigo_lider_politico, codigo_grupo_armado) VALUES
( 1,  4,  4),( 2,  5,  5),( 3,  6,  6),( 1,  7,  7),( 4,  9,  9),
( 5, 10, 10),( 6,  1,  1),( 7,  2,  2),( 8,  3,  3),( 9, 11, 11),
(10, 12, 12),(11, 13, 13),(12, 14, 14),(13, 15, 15),(14, 16, 16),
(15, 17, 17),(16, 18, 18),(17, 19, 19),(18, 20, 20),(19, 21, 21),
(20, 22, 22),(21, 23, 23),(22, 24, 24),(23, 25, 25),(24, 26, 26),
(25, 27, 27),(26, 28, 28),(27, 29, 29),(28, 30, 30),(29, 31, 31),
(30, 32, 32),(31, 33, 33),(32, 34, 34),(33, 35, 35),(34, 36, 36),
(35, 37, 37),(36, 38, 38),(37, 39, 39),(38, 40, 40),(39, 41, 41),
(40, 42, 42),(41, 43, 43),(42, 44, 44),(43, 45, 45),(44, 46, 46),
(45, 47, 47),(46, 48, 48),(47, 49, 49),(48, 50, 50),(49,  8,  8);

-- ================================================================
-- FIN DEL SCRIPT
-- Registros por tabla:
--   NIVELES_DESTRUCTIVOS                       : 50
--   TIPO_ORGANIZACION                          : 50
--   AYUDAS                                     : 50
--   REGIONES                                   : 50
--   RELIGIONES                                 : 50
--   MATERIAS_PRIMAS                            : 50
--   ETNIAS                                     : 50
--   PAISES                                     : 50
--   GRUPOS_ARMADOS                             : 50
--   CONFLICTOS                                 : 50
--   CONFLICTOS_TERRITORIALES                   : 13
--   CONFLICTOS_RELIGIOSOS                      : 12
--   CONFLICTOS_ECONOMICOS                      : 12
--   CONFLICTOS_RACIALES                        : 13
--   CONFLICTOS_TERRITORIALES_REGIONES          : 23
--   CONFLICTOS_RELIGIOSOS_RELIGIONES           : 13
--   CONFLICTOS_ECONOMICOS_MATERIAS_PRIMAS      : 14
--   CONFLICTOS_RACIALES_ETNIAS                 : 16
--   CONFLICTOS_PAISES                          : 50
--   CONFLICTOS_GRUPOS_ARMADOS                  : 50
--   ORGANIZACIONES_MEDIADORAS                  : 50
--   CONFLICTOS_ORGANIZACIONES_MEDIADORAS       : 54*
--   DIVISIONES                                 : 50
--   LIDERES_POLITICOS                          : 50
--   LIDERES_MILITARES                          : 50
--   ARMAS                                      : 50
--   TRAFICANTES                                : 50
--   TRAFICANTES_ARMAS                          : 50
--   SUMINISTROS                                : 50
--   ORGANIZACIONES_MEDIADORAS_LIDERES_POLITICOS: 49**
--
-- * CONFLICTOS_ORGANIZACIONES_MEDIADORAS: PK es (conflicto, org, ayuda)
--   lo que permite múltiples filas por conflicto+org con distinta ayuda
-- ** Las tablas de relación M:N no tienen el concepto de "50 registros"
--    igual que las tablas base, ya que su cardinalidad depende de PKs compuestas
-- ================================================================
