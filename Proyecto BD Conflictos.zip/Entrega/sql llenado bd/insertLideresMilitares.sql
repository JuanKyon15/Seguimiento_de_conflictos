INSERT INTO LIDERES_MILITARES
(nombre_lider_militar,rango,codigo_grupo_armado,numero_division,codigo_lider_politico_en_jefe,codigo_grupo_armado_en_jefe)
VALUES
('Ivan Petrenko','Coronel',1,1,1,1),
('Maksym Bondar','Teniente Coronel',1,2,2,1),
('Oleh Savchenko','Mayor',1,3,3,1),

('Sergei Ivanov','Coronel',2,1,4,2),
('Alexei Morozov','Mayor',2,2,5,2),
('Nikolai Volkov','Teniente Coronel',2,3,6,2),

('Fadi Karim','Coronel',3,1,7,3),
('Hassan Darwish','Mayor',3,2,8,3),
('Maher Suleiman','Capitan',3,3,7,3),

('Yusuf Ahmad','Coronel',4,1,9,4),
('Khaled Omar','Mayor',4,2,10,4),
('Sami Rashid','Capitan',4,3,9,4),

('Abdul Aziz','Coronel',5,1,11,5),
('Mohammed Tariq','Mayor',5,2,12,5),
('Farid Khan','Capitan',5,3,11,5),

('Mahmud Ali','Coronel',6,1,13,6),
('Nasser Salem','Mayor',6,2,13,6),

('Ali Hassan','Coronel',7,1,14,7),
('Karim Abbas','Mayor',7,2,14,7),

('Salem Omar','Coronel',8,1,15,8),
('Faris Ahmed','Mayor',8,2,15,8),

('Juan Herrera','Coronel',9,1,16,9),
('Luis Pardo','Mayor',9,2,16,9),

('Miguel Torres','Coronel',10,1,17,10),
('Carlos Rojas','Mayor',10,2,17,10),

('Abu Salem','Coronel',11,1,18,11),
('Abu Nidal','Coronel',12,1,19,12),
('Reza Mahmoud','Coronel',13,1,20,13),
('Li Cheng','Coronel',14,1,21,14),
('Eitan Levi','Coronel',15,1,22,15),


('Mustafa Kareem','Coronel',16,1,23,16),
('Kemal Arslan','Coronel',17,1,24,17),
('Mahmoud Fathi','Coronel',18,1,25,18),
('Yasir Abdullah','Coronel',19,1,26,19),
('Tadesse Alemu','Coronel',20,1,27,20),

('Ibrahim Musa','Coronel',21,1,28,21),
('Hamza Qureshi','Coronel',22,1,29,22),
('Vikram Singh','Coronel',23,1,30,23),
('Pak Yong Su','Coronel',24,1,31,24),
('Lee Joon Ho','Coronel',25,1,32,25),

('Aung Min','Coronel',26,1,33,26),
('Ricardo Suarez','Coronel',27,1,34,27),
('Pedro Castillo','Coronel',28,1,35,28),
('Bruno Almeida','Coronel',29,1,36,29),
('Diego Martinez','Coronel',30,1,37,30),

('Sebastian Rojas','Coronel',31,1,38,31),
('Jorge Paredes','Coronel',32,1,39,32),
('Mario Quispe','Coronel',33,1,40,33),
('Alejandro Ruiz','Coronel',34,1,41,34),
('Pierre Martin','Coronel',35,1,42,35),

('Klaus Weber','Coronel',36,1,43,36),
('James Walker','Coronel',37,1,44,37),
('Luca Bianchi','Coronel',38,1,45,38),
('Miguel Santos','Coronel',39,1,46,39),
('Robert Miller','Coronel',40,1,47,40),

('Igor Makarov','Coronel',41,1,48,41),
('Abdullahi Yusuf','Coronel',42,1,49,42),
('Mohamed Farah','Coronel',43,1,50,43),
('Baran Demir','Coronel',44,1,51,44),
('Javed Baloch','Coronel',45,1,52,45),

('Arul Kumar','Coronel',46,1,53,46),
('Hemed Dagalo','Coronel',47,1,54,47),
('Jean Mukasa','Coronel',48,1,55,48),
('Samuel Tesfay','Coronel',49,1,56,49),
('Arben Hoxha','Coronel',50,1,57,50);