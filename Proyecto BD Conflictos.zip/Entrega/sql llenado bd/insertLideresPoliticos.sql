INSERT INTO LIDERES_POLITICOS
(codigo_grupo_armado, nombre_lider_politico, descripcion_apoyos)
VALUES

-- Grupo 1 (3 l�deres)
(1,'Oleksandr Kovalenko','Apoyo gubernamental y aliados occidentales'),
(1,'Andriy Melnyk','Apoyo diplom�tico internacional'),
(1,'Mykola Shevchenko','Apoyo de autoridades regionales'),

-- Grupo 2 (3 l�deres)
(2,'Viktor Petrov','Apoyo estatal y militar'),
(2,'Sergei Volkov','Apoyo de sectores nacionalistas'),
(2,'Dmitri Sokolov','Apoyo pol�tico regional'),

-- Grupo 3 (2 l�deres)
(3,'Faisal Al Rashid','Apoyo del gobierno sirio'),
(3,'Omar Al Karim','Apoyo de l�deres locales'),

-- Grupo 4 (2 l�deres)
(4,'Kamal Hassan','Apoyo de comunidades del norte'),
(4,'Yusuf Hamdan','Apoyo regional'),

-- Grupo 5 (2 l�deres)
(5,'Mullah Abdul Rahman','Apoyo tribal y religioso'),
(5,'Abdul Karim','Apoyo de consejos locales'),

-- Grupos 6 al 50 (1 l�der cada uno)
(6,'Ismail Farouk','Apoyo de organizaciones palestinas'),
(7,'Hassan Nasser','Apoyo de comunidades chiitas'),
(8,'Mohamed Salem','Apoyo de la poblaci�n saharaui'),
(9,'Carlos Mendoza','Apoyo de comunidades rurales'),
(10,'Jorge Ramirez','Apoyo de antiguos combatientes'),
(11,'Abu Karim','Apoyo de facciones insurgentes'),
(12,'Abu Ibrahim','Apoyo de grupos radicales'),
(13,'Ali Reza','Apoyo de sectores revolucionarios'),
(14,'Zhang Wei','Apoyo gubernamental'),
(15,'David Cohen','Apoyo estatal'),
(16,'Mustafa Karim','Apoyo del gobierno iraqu�'),
(17,'Ahmet Demir','Apoyo institucional turco'),
(18,'Omar Hassan','Apoyo estatal'),
(19,'Abdul Rahim','Apoyo regional'),
(20,'Tesfaye Bekele','Apoyo gubernamental'),
(21,'Musa Ibrahim','Apoyo estatal'),
(22,'Imran Khan','Apoyo de sectores pakistan�es'),
(23,'Rajesh Kumar','Apoyo institucional'),
(24,'Kim Yong Ho','Apoyo gubernamental'),
(25,'Park Min Soo','Apoyo estatal'),
(26,'Aung Kyaw','Apoyo militar'),
(27,'Juan Perez','Apoyo institucional'),
(28,'Luis Fernandez','Apoyo pol�tico'),
(29,'Roberto Silva','Apoyo gubernamental'),
(30,'Martin Gomez','Apoyo militar'),
(31,'Diego Rojas','Apoyo institucional'),
(32,'Miguel Torres','Apoyo gubernamental'),
(33,'Alvaro Quispe','Apoyo comunitario'),
(34,'Fernando Ruiz','Apoyo estatal'),
(35,'Jean Dupont','Apoyo gubernamental'),
(36,'Hans M�ller','Apoyo estatal'),
(37,'William Smith','Apoyo institucional'),
(38,'Marco Rossi','Apoyo gubernamental'),
(39,'Javier Ortega','Apoyo estatal'),
(40,'Michael Johnson','Apoyo gubernamental'),
(41,'Dmitri Volkov','Apoyo de contratistas'),
(42,'Abubakar Yusuf','Apoyo insurgente'),
(43,'Ahmed Nur','Apoyo regional'),
(44,'Serhat Yilmaz','Apoyo kurdo'),
(45,'Akbar Baloch','Apoyo independentista'),
(46,'Velupillai Kumar','Apoyo tamil'),
(47,'Musa Dagalo','Apoyo local'),
(48,'Jean Bosco','Apoyo rebelde'),
(49,'Gebre Tesfay','Apoyo regional'),
(50,'Arben Krasniqi','Apoyo kosovar');