INSERT INTO ORGANIZACIONES_MEDIADORAS
(nombre_organizacion, id_tipo_organizacion, codigo_organizacion_dependiente)
VALUES
('Organizacion de las Naciones Unidas',3,NULL),
('Cruz Roja Internacional',3,NULL),
('UNICEF',3,NULL),
('ACNUR',3,NULL),
('Programa Mundial de Alimentos',3,NULL),
('Organizacion Mundial de la Salud',3,NULL),
('UNESCO',3,NULL),
('OTAN',3,NULL),
('Union Europea de Ayuda Humanitaria',3,NULL),
('Liga Arabe de Cooperacion',3,NULL),

('Medicos Sin Fronteras',2,NULL),
('Save the Children',2,NULL),
('Care International',2,NULL),
('Oxfam Internacional',2,NULL),
('World Vision',2,NULL),
('Mercy Corps',2,NULL),
('International Rescue Committee',2,NULL),
('Norwegian Refugee Council',2,NULL),
('Human Rights Watch',2,NULL),
('Amnistia Internacional',2,NULL),

('Defensa Civil Colombiana',1,NULL),
('Unidad Nacional para la Gestion del Riesgo',1,NULL),
('Agencia Colombiana para la Paz',1,NULL),
('Ministerio de Relaciones Exteriores de Colombia',1,NULL),
('Departamento de Ayuda Humanitaria de Brasil',1,NULL),
('Agencia Federal de Emergencias de Estados Unidos',1,NULL),
('Ministerio de Cooperacion de Espa�a',1,NULL),
('Agencia Francesa de Desarrollo',1,NULL),
('Ministerio de Ayuda Internacional de Canada',1,NULL),
('Agencia Alemana de Cooperacion',1,NULL),

('Fundacion Paz Global',2,NULL),
('Centro Internacional de Mediacion',2,NULL),
('Red Humanitaria Mundial',2,NULL),
('Fundacion Esperanza Internacional',2,NULL),
('Coalicion para la Paz Duradera',2,NULL),
('Instituto de Resolucion de Conflictos',2,NULL),
('Asociacion Global de Refugiados',2,NULL),
('Alianza Humanitaria Internacional',2,NULL),
('Fundacion Puentes para la Paz',2,NULL),
('Red Internacional de Dialogo',2,NULL),

('Observatorio Mundial de Conflictos',3,NULL),
('Centro Internacional de Derechos Humanos',3,NULL),
('Consejo Internacional de Mediacion',3,NULL),
('Comision Global para la Paz',3,NULL),
('Organizacion Internacional de Refugiados',3,NULL),
('Alianza Mundial para la Reconciliacion',3,NULL),
('Programa Internacional de Asistencia',3,NULL),
('Red Global de Cooperacion Humanitaria',3,NULL),
('Foro Internacional de Dialogo',3,NULL),
('Mision Internacional de Paz',3,NULL);

/* Dependen de la ONU */
UPDATE ORGANIZACIONES_MEDIADORAS
SET codigo_organizacion_dependiente = 1
WHERE codigo_organizacion IN (3,4,5,6,7);

/* Dependen de Cruz Roja Internacional */
UPDATE ORGANIZACIONES_MEDIADORAS
SET codigo_organizacion_dependiente = 2
WHERE codigo_organizacion IN (33,38,47);

/* Dependen del Centro Internacional de Mediacion */
UPDATE ORGANIZACIONES_MEDIADORAS
SET codigo_organizacion_dependiente = 32
WHERE codigo_organizacion IN (36,40,49);

/* Dependen del Consejo Internacional de Mediacion */
UPDATE ORGANIZACIONES_MEDIADORAS
SET codigo_organizacion_dependiente = 43
WHERE codigo_organizacion IN (44,50);