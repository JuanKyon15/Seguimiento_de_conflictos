INSERT INTO CONFLICTOS_TERRITORIALES (codigo_conflicto)
VALUES
(1),(5),(8),(9),(10),
(13),(14),(21),(22),(24),
(25),(26),(27),(29),(31),
(32),(35),(39),(43),(44),
(47),(48),(49),(50);

INSERT INTO CONFLICTOS_RELIGIOSOS (codigo_conflicto)
VALUES
(2),(3),(4),(12),(15),
(19),(23),(30),(34),(42),
(46);

INSERT INTO CONFLICTOS_ECONOMICOS (codigo_conflicto)
VALUES
(6),(11),(18),(28),(33),
(36),(40),(45);

INSERT INTO CONFLICTOS_RACIALES (codigo_conflicto)
VALUES
(7),(16),(17),(20),
(37),(38),(41);

INSERT INTO CONFLICTOS_TERRITORIALES_REGIONES
(codigo_conflicto,codigo_region)
VALUES
(1,1),(1,2),
(5,3),(5,4),
(8,5),(8,6),
(9,7),(9,8),
(10,9),(10,10),

(13,11),(13,12),
(14,13),(14,14),
(21,15),(21,16),
(22,17),(22,18),
(24,19),(24,20),

(25,21),(25,22),
(26,23),(26,24),
(27,25),(27,26),
(29,27),(29,28),
(31,29),(31,30),

(32,31),(32,32),
(35,33),(35,34),
(39,35),(39,36),
(43,37),(43,38),
(44,39),(44,40),

(47,41),(47,42),
(48,43),(48,44),
(49,45),(49,46),
(50,47),(50,48);

INSERT INTO CONFLICTOS_RELIGIOSOS_RELIGIONES
(codigo_conflicto,codigo_religion)
VALUES
(2,1),(2,2),
(3,1),(3,3),
(4,1),(4,2),
(12,1),(12,4),
(15,1),(15,5),

(19,1),(19,2),
(23,1),(23,6),
(30,1),(30,7),
(34,2),(34,3),
(42,1),(42,8),

(46,2),(46,5);

INSERT INTO CONFLICTOS_ECONOMICOS_MATERIAS_PRIMAS
(codigo_conflicto,codigo_materia_prima)
VALUES
(6,1),(6,2),
(11,1),(11,3),
(18,4),(18,5),
(28,6),(28,7),

(33,8),(33,9),
(36,10),(36,11),
(40,12),(40,13),
(45,14),(45,15);

INSERT INTO CONFLICTOS_RACIALES_ETNIAS
(codigo_conflicto,codigo_etnia)
VALUES
(7,1),(7,2),
(16,3),(16,4),
(17,5),(17,6),

(20,7),(20,8),
(37,9),(37,10),
(38,11),(38,12),
(41,13),(41,14);

