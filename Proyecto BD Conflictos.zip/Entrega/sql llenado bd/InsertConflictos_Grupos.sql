INSERT INTO CONFLICTOS_GRUPOS_ARMADOS
(codigo_conflicto, codigo_grupo_armado)
VALUES

-- Guerra Rusia-Ucrania
(1,1),
(1,2),

-- Guerra Civil Siria
(2,3),
(2,4),
(2,13),

-- Israel-Palestina
(3,6),
(3,15),

-- Yemen
(4,19),
(4,13),

-- Cachemira
(5,22),
(5,23),

-- Irak
(6,16),
(6,12),

-- Darfur
(7,19),
(7,47),

-- Kosovo
(8,50),
(8,36),

-- Nagorno Karabaj
(9,24),
(9,27),

-- Chechenia
(10,2),
(10,12),

-- Libia
(11,12),
(11,41),

-- Afganistan
(12,5),
(12,12),

-- Sahara Occidental
(13,8),
(13,18),

-- Kurdistan
(14,44),
(14,17),

-- Boko Haram
(15,42),
(15,21),

-- Sudan del Sur
(16,19),
(16,20),

-- Tigray
(17,20),
(17,49),

-- Delta del Niger
(18,21),
(18,9),

-- Somalia
(19,43),
(19,21),

-- Centroafricana
(20,20),
(20,43);