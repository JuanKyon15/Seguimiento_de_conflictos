INSERT INTO CONFLICTOS_PAISES (codigo_conflicto, codigo_Pais) VALUES
-- Guerra Rusia-Ucrania
(1,35),
(1,36),

-- Guerra Civil Siria
(2,39),

-- Israel-Palestina
(3,42),
(3,43),

-- Yemen
(4,44),

-- Cachemira
(5,48),
(5,49),

-- Irak
(6,40),

-- Darfur
(7,46),

-- Kosovo
(8,34),

-- Nagorno Karabaj
(9,24),
(9,27),

-- Chechenia
(10,36),

-- Libia
(11,45),

-- Afganist�n
(12,48),

-- Sahara Occidental
(13,47),

-- Kurdist�n
(14,40),
(14,41),
(14,17),

-- Boko Haram
(15,47),

-- Sud�n del Sur
(16,46),

-- Tigray
(17,46),

-- Delta del N�ger
(18,47),

-- Somalia
(19,47),

-- Centroafricana
(20,47);