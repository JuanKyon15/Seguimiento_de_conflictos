/*REGIONES*/
INSERT INTO REGIONES (nombre_region) VALUES
('Crimea'),
('Donetsk'),
('Lugansk'),
('Gaza'),
('Cisjordania'),
('Cachemira'),
('Kurdistan'),
('Chechenia'),
('Darfur'),
('Kosovo'),
('Nagorno Karabaj'),
('Abjasia'),
('Osetia del Sur'),
('Tigray'),
('Sahara Occidental'),
('Bajo Nilo'),
('Delta Oriental'),
('Monta�as del Norte'),
('Valle Central'),
('Costa Occidental'),
('Catalu�a'),
('Pais Vasco'),
('Andalucia'),
('Baviera'),
('Sajonia'),
('Escocia'),
('Irlanda del Norte'),
('Quebec'),
('California'),
('Texas'),
('Alaska'),
('Amazonas'),
('Patagonia'),
('Antioquia'),
('La Guajira'),
('Zulia'),
('Mato Grosso'),
('Puno'),
('Cusco'),
('Santa Cruz'),
('Galilea'),
('Sinai'),
('Mosul'),
('Alepo'),
('Idlib'),
('Punjab'),
('Bengala Occidental'),
('Tibet'),
('Xinjiang'),
('Manchuria');


/*RELIGIONES*/
INSERT INTO RELIGIONES (nombre_religion) VALUES
('Cristianismo'),
('Catolicismo'),
('Protestantismo'),
('Islam Sunita'),
('Islam Chiita'),
('Judaismo'),
('Hinduismo'),
('Budismo'),
('Sijismo'),
('Animismo');


/*ETNIAS*/
INSERT INTO ETNIAS (nombre_etnia) VALUES
('Kurdos'),
('Tutsi'),
('Hutu'),
('Uigures'),
('Pashtunes'),
('Tamiles'),
('Hazara'),
('Rohingya'),
('Serbios'),
('Croatas'),
('Bosnios'),
('Chechenos'),
('Tuareg'),
('Bereberes'),
('Yoruba'),
('Zulu'),
('Xhosa'),
('Aymara'),
('Quechua'),
('Mapuche');


/*MATERIAS PRIMAS*/
INSERT INTO MATERIAS_PRIMAS (nombre_materia_prima) VALUES
('Petroleo'),
('Gas Natural'),
('Oro'),
('Plata'),
('Litio'),
('Coltan'),
('Diamantes'),
('Uranio'),
('Carbon'),
('Cobre'),
('Hierro'),
('Bauxita'),
('Niquel'),
('Fosfatos'),
('Madera'),
('Cobalto'),
('Titanio'),
('Esta�o'),
('Zinc'),
('Manganeso');


/*AYUDAS*/
INSERT INTO AYUDAS (nombre_ayuda) VALUES
('Medica'),
('Diplomatica'),
('Presencial');


/*TIPO ORGANIZACION*/
INSERT INTO TIPO_ORGANIZACION (nombre_tipo_organizacion) VALUES
('Gubernamental'),
('No gubernamental'),
('Internacional');


/*NIVELES DESTRUCTIVOS*/
INSERT INTO NIVELES_DESTRUCTIVOS (descripcion) VALUES
('Muy Baja'),
('Baja'),
('Media'),
('Alta'),
('Extrema');